<?php
defined( 'ABSPATH' ) || exit;

class WOSMS_Admin {

	private static $instance = null;

	public static function init() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu',            array( $this, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );

		add_action( 'wp_ajax_wosms_save_settings',        array( $this, 'ajax_save_settings' ) );
		add_action( 'wp_ajax_wosms_test_connection',      array( $this, 'ajax_test_connection' ) );
		add_action( 'wp_ajax_wosms_get_balance',          array( $this, 'ajax_get_balance' ) );
		add_action( 'wp_ajax_wosms_save_templates',       array( $this, 'ajax_save_templates' ) );
		add_action( 'wp_ajax_wosms_save_admin_sms',       array( $this, 'ajax_save_admin_sms' ) );
		add_action( 'wp_ajax_wosms_search_customers',     array( $this, 'ajax_search_customers' ) );
		add_action( 'wp_ajax_wosms_send_manual_sms',      array( $this, 'ajax_send_manual_sms' ) );
		add_action( 'wp_ajax_wosms_save_offer_template',  array( $this, 'ajax_save_offer_template' ) );
		add_action( 'wp_ajax_wosms_delete_offer_template', array( $this, 'ajax_delete_offer_template' ) );
		add_action( 'wp_ajax_wosms_clear_history',        array( $this, 'ajax_clear_history' ) );
	}

	/* ── Menu ──────────────────────────────────────────────────────────── */

	public function register_menu() {
		add_menu_page(
			__( 'WO SMS', 'wo-sms' ),
			__( 'WO SMS', 'wo-sms' ),
			'manage_options',
			'wosms-notify',
			array( $this, 'render_sms_notify' ),
			'dashicons-email-alt',
			56
		);
		add_submenu_page(
			'wosms-notify',
			__( 'SMS Notify', 'wo-sms' ),
			__( 'SMS Notify', 'wo-sms' ),
			'manage_options',
			'wosms-notify',
			array( $this, 'render_sms_notify' )
		);
		add_submenu_page(
			'wosms-notify',
			__( 'Settings', 'wo-sms' ),
			__( 'Settings', 'wo-sms' ),
			'manage_options',
			'wosms-settings',
			array( $this, 'render_settings' )
		);
	}

	public function render_sms_notify() {
		include WOSMS_PLUGIN_DIR . 'admin/views/sms-notify.php';
	}

	public function render_settings() {
		include WOSMS_PLUGIN_DIR . 'admin/views/settings.php';
	}

	/* ── Assets ────────────────────────────────────────────────────────── */

	public function enqueue_assets( $hook ) {
		if ( strpos( $hook, 'wosms-notify' ) === false && strpos( $hook, 'wosms-settings' ) === false ) {
			return;
		}
		wp_enqueue_style(
			'wosms-admin',
			WOSMS_PLUGIN_URL . 'assets/css/admin.css',
			array(),
			filemtime( WOSMS_PLUGIN_DIR . 'assets/css/admin.css' )
		);
		wp_enqueue_script(
			'wosms-admin',
			WOSMS_PLUGIN_URL . 'assets/js/admin.js',
			array( 'jquery' ),
			filemtime( WOSMS_PLUGIN_DIR . 'assets/js/admin.js' ),
			true
		);

		$offers = get_option( 'wosms_offer_templates', array() );
		$offers = is_array( $offers ) ? array_values( $offers ) : array();

		wp_localize_script( 'wosms-admin', 'wosms_params', array(
			'ajax_url'        => admin_url( 'admin-ajax.php' ),
			'nonce'           => wp_create_nonce( 'wosms_nonce' ),
			'site_name'       => get_bloginfo( 'name' ),
			'offer_templates' => $offers,
			'i18n'            => array(
				'saving'          => __( 'Saving...', 'wo-sms' ),
				'testing'         => __( 'Testing...', 'wo-sms' ),
				'sending'         => __( 'Sending...', 'wo-sms' ),
				'searching'       => __( 'Searching...', 'wo-sms' ),
				'connected'       => __( 'Connected', 'wo-sms' ),
				'test_connection' => __( 'Test Connection', 'wo-sms' ),
			),
		) );
	}

	/* ── Settings ──────────────────────────────────────────────────────── */

	public function ajax_save_settings() {
		check_ajax_referer( 'wosms_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wo-sms' ) ) );
		}

		$settings = get_option( 'wosms_settings', array() );
		if ( ! is_array( $settings ) ) {
			$settings = array();
		}
		$settings['enabled'] = ! empty( $_POST['sms_enabled'] ) ? '1' : '';
		update_option( 'wosms_settings', $settings );

		update_option( 'wosms_username',    sanitize_text_field( wp_unslash( $_POST['username'] ?? '' ) ) );
		update_option( 'wosms_api_key',     sanitize_text_field( wp_unslash( $_POST['api_key'] ?? '' ) ) );
		update_option( 'wosms_sender_id',   sanitize_text_field( wp_unslash( $_POST['sender_id'] ?? '' ) ) );
		update_option( 'wosms_signature',   sanitize_textarea_field( wp_unslash( $_POST['signature'] ?? '' ) ) );
		update_option( 'wosms_date_format', sanitize_text_field( wp_unslash( $_POST['date_format'] ?? '%d.%m.%y' ) ) );

		wp_send_json_success( array( 'message' => __( 'Settings saved successfully.', 'wo-sms' ) ) );
	}

	public function ajax_test_connection() {
		check_ajax_referer( 'wosms_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wo-sms' ) ) );
		}
		$balance = $this->fetch_balance();
		if ( $balance['ok'] ) {
			$msg = __( 'Connection successful!', 'wo-sms' );
			if ( $balance['balance'] !== null ) {
				$msg .= ' ' . sprintf( __( 'Balance: %s', 'wo-sms' ), $balance['balance'] );
			}
			wp_send_json_success( array( 'message' => $msg, 'balance' => $balance['balance'] ) );
		}
		wp_send_json_error( array( 'message' => $balance['message'] ) );
	}

	public function ajax_get_balance() {
		check_ajax_referer( 'wosms_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wo-sms' ) ) );
		}
		$balance = $this->fetch_balance();
		if ( ! $balance['ok'] ) {
			/* Surface the gateway's own wording (e.g. "IP Black List.") instead
			 * of leaving the balance box as a silent dash. */
			wp_send_json_error( array( 'message' => $balance['message'] ) );
		}
		wp_send_json_success( array( 'balance' => $balance['balance'] ) );
	}

	/**
	 * Query the SMS gateway balance endpoint.
	 *
	 * @return array{ ok:bool, balance:?string, message:string }
	 */
	private function fetch_balance() {
		$username = trim( (string) get_option( 'wosms_username', '' ) );
		$api_key  = trim( (string) get_option( 'wosms_api_key', '' ) );
		if ( empty( $api_key ) ) {
			return array( 'ok' => false, 'balance' => null, 'message' => __( 'Please save an API key first.', 'wo-sms' ) );
		}
		$resp = wosms_api_post( WOSMS_BALANCE_PATH, array(
			'UserName' => $username,
			'Apikey'   => $api_key,
		), 15 );

		$parsed = wosms_parse_api_response( $resp );

		if ( ! $parsed['success'] ) {
			$msg = $parsed['result'] !== '' ? $parsed['result'] : $parsed['debug'];
			return array( 'ok' => false, 'balance' => null, 'message' => $msg );
		}

		/* The gateway reports the balance in responseResult; fall back to the
		 * usual balance keys in case the panel returns a richer payload. */
		$decoded = $parsed['decoded'];
		$raw     = $parsed['result'];
		if ( ! is_numeric( $raw ) ) {
			$raw = $decoded['balance']
				?? $decoded['Balance']
				?? $decoded['current_balance']
				?? $decoded['data']['balance']
				?? $decoded['sms_balance']
				?? $decoded['data']['sms_balance']
				?? $raw;
		}

		$bal = null;
		if ( is_numeric( $raw ) ) {
			$bal = '৳' . number_format( (float) $raw, 2 );
		} elseif ( ! empty( $raw ) ) {
			$bal = (string) $raw;
		}

		return array( 'ok' => true, 'balance' => $bal, 'message' => '' );
	}

	/* ── Templates ─────────────────────────────────────────────────────── */

	public function ajax_save_templates() {
		check_ajax_referer( 'wosms_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wo-sms' ) ) );
		}
		$statuses  = array_keys( wosms_default_templates() );
		$templates = array();
		$enabled   = array();
		foreach ( $statuses as $s ) {
			$templates[ $s ] = sanitize_textarea_field( wp_unslash( $_POST[ 'tpl_' . $s ] ?? '' ) );
			if ( ! empty( $_POST[ 'en_' . $s ] ) ) {
				$enabled[] = $s;
			}
		}
		update_option( 'wosms_templates', $templates );

		$settings = get_option( 'wosms_settings', array() );
		if ( ! is_array( $settings ) ) {
			$settings = array();
		}
		$settings['enabled_statuses'] = $enabled;
		update_option( 'wosms_settings', $settings );

		wp_send_json_success( array( 'message' => __( 'SMS templates saved successfully.', 'wo-sms' ) ) );
	}

	public function ajax_save_admin_sms() {
		check_ajax_referer( 'wosms_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wo-sms' ) ) );
		}
		update_option( 'wosms_admin_sms_enabled', ! empty( $_POST['enabled'] ) ? '1' : '' );
		update_option( 'wosms_admin_sms_phone',   sanitize_text_field( wp_unslash( $_POST['phone'] ?? '' ) ) );
		update_option( 'wosms_admin_sms_msg',     sanitize_textarea_field( wp_unslash( $_POST['msg'] ?? '' ) ) );
		wp_send_json_success();
	}

	/* ── Quick / Manual SMS ────────────────────────────────────────────── */

	public function ajax_search_customers() {
		check_ajax_referer( 'wosms_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error();
		}
		$term        = sanitize_text_field( wp_unslash( $_POST['term'] ?? '' ) );
		$results     = array();
		$seen_phones = array();

		$user_args = array(
			'role__in' => array( 'customer', 'subscriber', 'administrator', 'editor', 'shop_manager' ),
			'number'   => 20,
			'orderby'  => 'display_name',
		);
		if ( ! empty( $term ) ) {
			$user_args['search']         = '*' . $term . '*';
			$user_args['search_columns'] = array( 'display_name', 'user_email', 'user_login' );
		}
		$users = get_users( $user_args );

		if ( ! empty( $term ) ) {
			$phone_users  = get_users( array(
				'number'     => 20,
				'meta_query' => array( array( 'key' => 'billing_phone', 'value' => $term, 'compare' => 'LIKE' ) ),
			) );
			$existing_ids = array_map( function ( $u ) { return $u->ID; }, $users );
			foreach ( $phone_users as $pu ) {
				if ( ! in_array( $pu->ID, $existing_ids, true ) ) {
					$users[] = $pu;
				}
			}
		}

		foreach ( $users as $user ) {
			$phone     = get_user_meta( $user->ID, 'billing_phone', true );
			$results[] = array(
				'id'    => $user->ID,
				'name'  => $user->display_name,
				'phone' => $phone ?: '',
				'email' => $user->user_email,
				'type'  => 'user',
			);
			if ( $phone ) {
				$seen_phones[] = $phone;
			}
		}

		if ( class_exists( 'WooCommerce' ) ) {
			$order_args = array(
				'limit'   => 30,
				'orderby' => 'date',
				'order'   => 'DESC',
				'return'  => 'objects',
			);
			if ( ! empty( $term ) ) {
				/* WooCommerce's own order search — works on both the legacy
				 * post-based store and HPOS (custom order tables), where a
				 * meta_query on _billing_* would not match. */
				$order_args['s'] = $term;
			} else {
				$order_args['customer_id'] = 0;
			}
			$orders            = wc_get_orders( $order_args );
			$seen_order_phones = array();
			foreach ( $orders as $order ) {
				$phone = $order->get_billing_phone();
				if ( ! $phone || in_array( $phone, $seen_phones, true ) || in_array( $phone, $seen_order_phones, true ) ) {
					continue;
				}
				$name  = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ) ?: 'Guest';
				$label = $order->get_customer_id() ? $name : $name . ' (Guest)';
				$results[] = array(
					'id'    => 'order_' . $order->get_id(),
					'name'  => $label,
					'phone' => $phone,
					'email' => $order->get_billing_email(),
					'type'  => 'guest',
				);
				$seen_order_phones[] = $phone;
			}
		}

		wp_send_json_success( $results );
	}

	public function ajax_send_manual_sms() {
		check_ajax_referer( 'wosms_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wo-sms' ) ) );
		}
		$mobiles_raw = sanitize_text_field( wp_unslash( $_POST['mobiles'] ?? '' ) );
		$message     = sanitize_textarea_field( wp_unslash( $_POST['message'] ?? '' ) );
		if ( empty( $mobiles_raw ) || empty( $message ) ) {
			wp_send_json_error( array( 'message' => __( 'Mobile number and message are required.', 'wo-sms' ) ) );
		}

		/* Resolve {site_name}; the gateway signature is appended in wosms_send_sms(). */
		$message = str_replace( '{site_name}', get_bloginfo( 'name' ), $message );

		$mobiles    = array_filter( array_map( 'trim', explode( ',', $mobiles_raw ) ) );
		$sent       = 0;
		$failed     = 0;
		$last_debug = '';

		foreach ( $mobiles as $mobile ) {
			$mobile = wosms_normalize_phone( $mobile );
			$result = wosms_send_sms( $mobile, $message );
			if ( $result['success'] ) {
				$sent++;
			} else {
				$failed++;
				$last_debug = $result['debug'];
			}
			wosms_log_sms( $mobile, $message, $result['success'] ? 'sent' : 'failed', 'manual' );
		}

		if ( $sent > 0 ) {
			wp_send_json_success( array( 'message' => sprintf( __( 'Sent: %d | Failed: %d', 'wo-sms' ), $sent, $failed ) ) );
		}
		$debug_msg = ! empty( $last_debug ) ? ' [' . $last_debug . ']' : '';
		wp_send_json_error( array( 'message' => sprintf( __( 'All failed (%d). Check SMS settings.', 'wo-sms' ), $failed ) . $debug_msg ) );
	}

	/* ── Offer templates ───────────────────────────────────────────────── */

	public function ajax_save_offer_template() {
		check_ajax_referer( 'wosms_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error();
		}
		$id      = sanitize_text_field( wp_unslash( $_POST['id'] ?? '' ) );
		$name    = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );
		$message = sanitize_textarea_field( wp_unslash( $_POST['message'] ?? '' ) );
		if ( empty( $name ) || empty( $message ) ) {
			wp_send_json_error( array( 'message' => __( 'Name and message are required.', 'wo-sms' ) ) );
		}
		$templates = get_option( 'wosms_offer_templates', array() );
		if ( ! is_array( $templates ) ) {
			$templates = array();
		}
		if ( $id ) {
			foreach ( $templates as &$t ) {
				if ( $t['id'] === $id ) {
					$t['name']    = $name;
					$t['message'] = $message;
					break;
				}
			}
			unset( $t );
		} else {
			$id          = uniqid( 'otpl_', true );
			$templates[] = array( 'id' => $id, 'name' => $name, 'message' => $message );
		}
		update_option( 'wosms_offer_templates', $templates );
		wp_send_json_success( array( 'id' => $id, 'name' => $name, 'message' => $message ) );
	}

	public function ajax_delete_offer_template() {
		check_ajax_referer( 'wosms_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error();
		}
		$id        = sanitize_text_field( wp_unslash( $_POST['id'] ?? '' ) );
		$templates = get_option( 'wosms_offer_templates', array() );
		$templates = is_array( $templates ) ? array_values( array_filter( $templates, fn( $t ) => $t['id'] !== $id ) ) : array();
		update_option( 'wosms_offer_templates', $templates );
		wp_send_json_success();
	}

	public function ajax_clear_history() {
		check_ajax_referer( 'wosms_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error();
		}
		update_option( 'wosms_history', array() );
		wp_send_json_success();
	}
}

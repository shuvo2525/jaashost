<?php
/**
 * Plugin Name: WO SMS
 * Plugin URI:  https://api.resellcore.com/
 * Description: WooCommerce SMS Notification — customers ও admin কে অর্ডার স্ট্যাটাস অনুযায়ী স্বয়ংক্রিয় SMS পাঠায়।
 * Version:     1.0.0
 * Author:      Putul IT
 * Author URI:  https://api.resellcore.com/
 * Text Domain: wo-sms
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 5.0
 */

defined( 'ABSPATH' ) || exit;

define( 'WOSMS_VERSION',     '1.0.0' );
define( 'WOSMS_PLUGIN_FILE', __FILE__ );
define( 'WOSMS_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'WOSMS_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );

/**
 * ── SMS Gateway API (MiM SMS compatible) ──
 * The gateway speaks the MiM SMS protocol: HTTP POST with a JSON body
 * containing UserName / Apikey / MobileNumber / CampaignId / SenderName /
 * TransactionType / Message. It always answers with HTTP 200 — the real
 * outcome lives in the JSON `statusCode` / `status` fields.
 * Endpoints are defined here so they can be adjusted in one place if the
 * panel exposes different routes. Each one can also be overridden from
 * wp-config.php — define the constant there and it wins, no need to edit
 * the plugin when the gateway moves the API to another host:
 *
 *     define( 'WOSMS_API_BASE', 'https://api.resellcore.com/' );
 */
if ( ! defined( 'WOSMS_API_BASE' ) ) {
	define( 'WOSMS_API_BASE', 'https://smsapi.resellcore.com/' );
}
if ( ! defined( 'WOSMS_SEND_PATH' ) ) {
	define( 'WOSMS_SEND_PATH', 'api/SmsSending/SMS' );          // SMS পাঠানোর endpoint
}
if ( ! defined( 'WOSMS_BALANCE_PATH' ) ) {
	define( 'WOSMS_BALANCE_PATH', 'api/SmsSending/balanceCheck' ); // ব্যালেন্স চেক endpoint
}

require_once WOSMS_PLUGIN_DIR . 'admin/class-wosms-admin.php';

add_action( 'plugins_loaded', array( 'WOSMS_Admin', 'init' ) );

/* Add a "Settings" action link on the Plugins list row. */
add_filter( 'plugin_action_links_' . plugin_basename( WOSMS_PLUGIN_FILE ), 'wosms_plugin_action_links' );
function wosms_plugin_action_links( $links ) {
	$settings = '<a href="' . esc_url( admin_url( 'admin.php?page=wosms-settings' ) ) . '">' . esc_html__( 'Settings', 'wo-sms' ) . '</a>';
	array_unshift( $links, $settings );
	return $links;
}

/* Declare WooCommerce HPOS (custom order tables) compatibility so WooCommerce
 * does not flag the plugin as incompatible. */
add_action( 'before_woocommerce_init', function () {
	if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', WOSMS_PLUGIN_FILE, true );
	}
} );

/* ─────────────────────────────────────────────────────────────────────────
 *  Core helpers
 * ────────────────────────────────────────────────────────────────────── */

/**
 * Get the API base URL (always trailing-slashed).
 */
function wosms_api_base() {
	return trailingslashit( WOSMS_API_BASE );
}

/**
 * Normalize a Bangladeshi phone number to 8801XXXXXXXXX form.
 */
function wosms_normalize_phone( $phone ) {
	$phone = preg_replace( '/[^0-9]/', '', (string) $phone );
	if ( strlen( $phone ) === 11 && substr( $phone, 0, 2 ) === '01' ) {
		$phone = '88' . $phone;
	} elseif ( strlen( $phone ) === 10 && substr( $phone, 0, 1 ) === '1' ) {
		$phone = '880' . $phone;
	}
	return $phone;
}

/**
 * Send a single SMS through the SMS gateway.
 *
 * @return array{ success:bool, debug:string }
 */
function wosms_send_sms( $mobile, $message ) {
	$username  = trim( (string) get_option( 'wosms_username', '' ) );
	$api_key   = trim( (string) get_option( 'wosms_api_key', '' ) );
	$sender_id = trim( (string) get_option( 'wosms_sender_id', '' ) );

	if ( empty( $api_key ) ) {
		return array( 'success' => false, 'debug' => 'API key not configured.' );
	}

	$mobile = wosms_normalize_phone( $mobile );
	if ( strlen( $mobile ) < 11 ) {
		return array( 'success' => false, 'debug' => 'Invalid mobile number.' );
	}

	/* Append the configured signature (e.g. "-MiM SMS") if it is not already
	 * part of the message. */
	$signature = trim( (string) get_option( 'wosms_signature', '' ) );
	if ( $signature !== '' && mb_strpos( $message, $signature ) === false ) {
		$message = rtrim( $message ) . ' ' . $signature;
	}

	/* MiM-style API: POST a JSON body to /api/SmsSending/SMS. The gateway
	 * answers HTTP 200 even for errors, so the JSON statusCode decides. */
	$payload = array(
		'UserName'        => $username,
		'Apikey'          => $api_key,
		'MobileNumber'    => $mobile,
		'CampaignId'      => 'null',
		'SenderName'      => $sender_id,
		'TransactionType' => 'T',
		'Message'         => html_entity_decode( $message, ENT_QUOTES, 'UTF-8' ),
	);

	return wosms_parse_api_response( wosms_api_post( WOSMS_SEND_PATH, $payload, 30 ) );
}

/**
 * POST a JSON payload to a gateway endpoint.
 *
 * The request is pinned to IPv4. The gateway whitelists a single IPv4
 * address, but its host also publishes AAAA records — on a server with IPv6
 * connectivity cURL would prefer IPv6, the gateway would see an address that
 * is not on the whitelist, and every call would come back "IP Black List."
 * even though the IPv4 was whitelisted correctly.
 *
 * Define WOSMS_FORCE_IPV4 as false in wp-config.php to disable the pinning.
 *
 * @param string $path    Endpoint path, relative to the API base.
 * @param array  $payload Body to JSON-encode.
 * @param int    $timeout Request timeout in seconds.
 * @return array|WP_Error Raw wp_remote_post() result.
 */
function wosms_api_post( $path, $payload, $timeout = 20 ) {
	$pin_ipv4 = ! defined( 'WOSMS_FORCE_IPV4' ) || WOSMS_FORCE_IPV4;
	$callback = null;

	if ( $pin_ipv4 && defined( 'CURL_IPRESOLVE_V4' ) ) {
		$callback = function ( $handle ) {
			curl_setopt( $handle, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4 );
		};
		add_action( 'http_api_curl', $callback );
	}

	$resp = wp_remote_post( wosms_api_base() . $path, array(
		'timeout' => $timeout,
		'headers' => array(
			'Content-Type' => 'application/json',
			'Accept'       => 'application/json',
		),
		'body'    => wp_json_encode( $payload ),
	) );

	if ( $callback ) {
		remove_action( 'http_api_curl', $callback );
	}

	return $resp;
}

/**
 * Interpret an SMS gateway (MiM-style) API response.
 *
 * The gateway always returns HTTP 200; success is signalled by
 * statusCode "200" / status "Success" inside the JSON body.
 *
 * @param array|WP_Error $resp Raw wp_remote_* response.
 * @return array{ success:bool, debug:string, result:string, decoded:array }
 */
function wosms_parse_api_response( $resp ) {
	if ( is_wp_error( $resp ) ) {
		$msg = 'WP Error: ' . $resp->get_error_message();
		return array( 'success' => false, 'debug' => $msg, 'result' => $msg, 'decoded' => array() );
	}

	$http_code = (int) wp_remote_retrieve_response_code( $resp );
	$body      = wp_remote_retrieve_body( $resp );
	if ( substr( $body, 0, 3 ) === "\xEF\xBB\xBF" ) {
		$body = substr( $body, 3 );
	}
	$decoded = json_decode( $body, true );
	$decoded = is_array( $decoded ) ? $decoded : array();

	$status_code = (string) ( $decoded['statusCode'] ?? $decoded['StatusCode'] ?? '' );
	$status_val  = strtolower( (string) ( $decoded['status'] ?? $decoded['Status'] ?? '' ) );
	$result      = (string) ( $decoded['responseResult'] ?? $decoded['ResponseResult'] ?? '' );

	$ok = ( $http_code >= 200 && $http_code < 300 )
		&& ( $status_code === '200' || in_array( $status_val, array( 'success', 'sent', 'delivered' ), true ) );

	$debug = 'HTTP ' . $http_code;
	if ( $status_code !== '' ) {
		$debug .= ' | API ' . $status_code;
	}
	if ( $result !== '' ) {
		$debug .= ' | ' . $result;
	} elseif ( $status_code === '' ) {
		$debug .= ' | ' . substr( $body, 0, 200 );
	}

	return array( 'success' => $ok, 'debug' => $debug, 'result' => $result, 'decoded' => $decoded );
}

/**
 * The public IP this server sends outgoing requests from — the address that
 * has to be whitelisted in the SMS panel. Cached for a day.
 *
 * $_SERVER['SERVER_ADDR'] is unreliable behind Cloudflare/NAT/load balancers,
 * so ask an echo service first and only fall back to the local value.
 *
 * @param int $version 4 or 6. IPv6 matters because the gateway host publishes
 *                     AAAA records — a server with IPv6 would otherwise reach
 *                     the API from an address nobody thought to whitelist.
 * @return string IP address, or '' if it could not be determined.
 */
function wosms_server_ip( $version = 4 ) {
	$version   = ( 6 === (int) $version ) ? 6 : 4;
	$cache_key = 'wosms_server_ip_v' . $version;

	$cached = get_transient( $cache_key );
	if ( $cached !== false ) {
		return (string) $cached;
	}

	$services = ( 6 === $version )
		? array( 'https://api6.ipify.org', 'https://ipv6.icanhazip.com' )
		: array( 'https://api4.ipify.org', 'https://ipv4.icanhazip.com' );
	$flag = ( 6 === $version ) ? FILTER_FLAG_IPV6 : FILTER_FLAG_IPV4;

	$ip = '';
	foreach ( $services as $service ) {
		$resp = wp_remote_get( $service, array( 'timeout' => 8 ) );
		if ( is_wp_error( $resp ) ) {
			continue;
		}
		$candidate = trim( wp_remote_retrieve_body( $resp ) );
		if ( filter_var( $candidate, FILTER_VALIDATE_IP, $flag ) ) {
			$ip = $candidate;
			break;
		}
	}

	if ( $ip === '' && 4 === $version && ! empty( $_SERVER['SERVER_ADDR'] ) ) {
		$local = filter_var( wp_unslash( $_SERVER['SERVER_ADDR'] ), FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 );
		$ip    = $local ? $local : '';
	}

	/* An empty IPv6 result just means the server has no IPv6 route — cache it
	 * briefly so the settings page does not retry on every load. */
	set_transient( $cache_key, $ip, $ip === '' ? HOUR_IN_SECONDS : DAY_IN_SECONDS );
	return $ip;
}

/**
 * Format a timestamp using the admin-configured date format.
 * Accepts strftime-style tokens (e.g. "%d.%m.%y") and converts them to
 * PHP date() tokens so it works on PHP 8.1+ where strftime is removed.
 */
function wosms_format_date( $timestamp ) {
	$fmt = trim( (string) get_option( 'wosms_date_format', '%d.%m.%y' ) );
	if ( $fmt === '' ) {
		$fmt = '%d.%m.%y';
	}
	$map = array(
		'%d' => 'd', '%m' => 'm', '%Y' => 'Y', '%y' => 'y',
		'%H' => 'H', '%I' => 'h', '%M' => 'i', '%S' => 's',
		'%p' => 'A', '%B' => 'F', '%b' => 'M', '%A' => 'l', '%a' => 'D',
	);
	$php_fmt = strtr( $fmt, $map );
	return date( $php_fmt, $timestamp );
}

/**
 * Append a row to the SMS history log (kept to last 200).
 */
function wosms_log_sms( $mobile, $message, $status, $type = 'auto', $order_id = 0 ) {
	$history = get_option( 'wosms_history', array() );
	if ( ! is_array( $history ) ) {
		$history = array();
	}
	array_unshift( $history, array(
		'date'     => current_time( 'mysql' ),
		'mobile'   => $mobile,
		'message'  => $message,
		'status'   => $status,
		'type'     => $type,
		'order_id' => $order_id,
	) );
	if ( count( $history ) > 200 ) {
		$history = array_slice( $history, 0, 200 );
	}
	update_option( 'wosms_history', $history, false );
}

/**
 * Replace template placeholders for a given order.
 */
function wosms_parse_placeholders( $message, $order, $extra = array() ) {
	$customer_name = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
	if ( empty( $customer_name ) ) {
		$customer_name = __( 'Customer', 'wo-sms' );
	}
	$replace = array_merge( array(
		'{customer_name}'  => $customer_name,
		'{order_id}'       => $order->get_order_number(),
		'{customer_phone}' => $order->get_billing_phone(),
		'{order_total}'    => number_format( (float) $order->get_total(), 2 ),
		'{site_name}'      => get_bloginfo( 'name' ),
	), $extra );
	return str_replace( array_keys( $replace ), array_values( $replace ), $message );
}

/* ─────────────────────────────────────────────────────────────────────────
 *  Auto SMS on order status change (customer notification)
 * ────────────────────────────────────────────────────────────────────── */

add_action( 'woocommerce_order_status_changed', 'wosms_send_order_status_sms', 10, 4 );
function wosms_send_order_status_sms( $order_id, $from_status, $to_status, $order ) {
	$settings = get_option( 'wosms_settings', array() );

	/* Block only if the user explicitly disabled SMS. */
	if ( isset( $settings['enabled'] ) && empty( $settings['enabled'] ) ) {
		return;
	}

	/* Map WooCommerce statuses to our template keys. */
	$status_map = array(
		'on-hold'   => 'hold',
		'refunded'  => 'return',
		'completed' => 'delivered',
	);
	$template_key = isset( $status_map[ $to_status ] ) ? $status_map[ $to_status ] : $to_status;

	$defaults = wosms_default_templates();
	if ( ! isset( $defaults[ $template_key ] ) ) {
		return; // Not a status we handle.
	}

	$all_statuses     = array_keys( $defaults );
	$enabled_statuses = isset( $settings['enabled_statuses'] ) ? (array) $settings['enabled_statuses'] : $all_statuses;
	if ( ! in_array( $template_key, $enabled_statuses, true ) ) {
		return; // This status template is turned off.
	}

	$templates = get_option( 'wosms_templates', array() );
	$message   = ! empty( $templates[ $template_key ] ) ? $templates[ $template_key ] : $defaults[ $template_key ];
	$message   = wosms_parse_placeholders( $message, $order, array(
		'{order_status}' => wc_get_order_status_name( $to_status ),
	) );

	$phone = $order->get_billing_phone();
	if ( empty( preg_replace( '/[^0-9]/', '', $phone ) ) ) {
		wosms_log_sms( '—', "Order #{$order_id}: No phone number.", 'failed', 'auto', $order_id );
		return;
	}
	$phone = wosms_normalize_phone( $phone );

	$result = wosms_send_sms( $phone, $message );
	wosms_log_sms( $phone, $message, $result['success'] ? 'sent' : 'failed', 'auto', $order_id );
}

/* ─────────────────────────────────────────────────────────────────────────
 *  Admin SMS on new order
 * ────────────────────────────────────────────────────────────────────── */

add_action( 'woocommerce_checkout_order_processed',           'wosms_admin_sms_classic', 20, 1 );
add_action( 'woocommerce_store_api_checkout_order_processed', 'wosms_admin_sms_block',   20, 1 );

function wosms_admin_sms_classic( $order_id ) {
	wosms_do_admin_new_order_sms( (int) $order_id );
}
function wosms_admin_sms_block( $order ) {
	if ( is_a( $order, 'WC_Abstract_Order' ) ) {
		wosms_do_admin_new_order_sms( $order->get_id() );
	}
}

function wosms_do_admin_new_order_sms( $order_id ) {
	static $sent = array();
	if ( in_array( $order_id, $sent, true ) ) {
		return;
	}
	$sent[] = $order_id;

	if ( get_option( 'wosms_admin_sms_enabled' ) !== '1' ) {
		return;
	}

	$raw_phone = get_option( 'wosms_admin_sms_phone', '' );
	if ( empty( preg_replace( '/[^0-9]/', '', $raw_phone ) ) ) {
		return;
	}
	$admin_phone = wosms_normalize_phone( $raw_phone );

	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		return;
	}

	$default_msg = 'নতুন অর্ডার! #{order_id} - {customer_name} - ফোন: {customer_phone} - মোট: {order_total} টাকা। {site_name}';
	$msg_tpl     = get_option( 'wosms_admin_sms_msg', $default_msg );
	if ( empty( trim( $msg_tpl ) ) ) {
		$msg_tpl = $default_msg;
	}
	$message = wosms_parse_placeholders( $msg_tpl, $order );

	$result = wosms_send_sms( $admin_phone, $message );
	wosms_log_sms( $admin_phone, $message, $result['success'] ? 'sent' : 'failed', 'auto', $order_id );
}

/* ─────────────────────────────────────────────────────────────────────────
 *  Default templates + status labels (shared across views & engine)
 * ────────────────────────────────────────────────────────────────────── */

function wosms_default_templates() {
	return array(
		'pending'    => 'প্রিয় {customer_name}, আপনার অর্ডার #{order_id} সফলভাবে গ্রহণ করা হয়েছে। ধন্যবাদ। {site_name}',
		'paid'       => 'প্রিয় {customer_name}, আপনার অর্ডার #{order_id} এর পেমেন্ট সফলভাবে সম্পন্ন হয়েছে। ধন্যবাদ। {site_name}',
		'confirmed'  => 'প্রিয় {customer_name}, আপনার অর্ডার #{order_id} কনফার্ম করা হয়েছে। আমরা শীঘ্রই এটি প্রসেস করব। {site_name}',
		'processing' => 'প্রিয় {customer_name}, আপনার অর্ডার #{order_id} বর্তমানে প্যাকেজিং অবস্থায় আছে। {site_name}',
		'shipped'    => 'প্রিয় {customer_name}, আপনার অর্ডার #{order_id} কুরিয়ারে পাঠানো হয়েছে। শীঘ্রই হাতে পাবেন। {site_name}',
		'delivered'  => 'প্রিয় {customer_name}, আপনার অর্ডার #{order_id} সফলভাবে ডেলিভারি করা হয়েছে। আমাদের সাথে থাকার জন্য ধন্যবাদ। {site_name}',
		'cancelled'  => 'প্রিয় {customer_name}, দুঃখিত, আপনার অর্ডার #{order_id} বাতিল করা হয়েছে। বিস্তারিত জানতে যোগাযোগ করুন। {site_name}',
		'return'     => 'প্রিয় {customer_name}, আপনার অর্ডার #{order_id} রিটার্ন করা হয়েছে। {site_name}',
		'hold'       => 'প্রিয় {customer_name}, আপনার অর্ডার #{order_id} সাময়িকভাবে হোল্ডে রাখা হয়েছে। {site_name}',
	);
}

function wosms_status_labels() {
	return array(
		'pending'    => __( 'Order Placed (Pending)', 'wo-sms' ),
		'paid'       => __( 'Payment Confirmed (Paid)', 'wo-sms' ),
		'confirmed'  => __( 'Order Confirmed', 'wo-sms' ),
		'processing' => __( 'Packaging', 'wo-sms' ),
		'shipped'    => __( 'Shipped', 'wo-sms' ),
		'delivered'  => __( 'Delivered', 'wo-sms' ),
		'cancelled'  => __( 'Cancelled', 'wo-sms' ),
		'return'     => __( 'Returned', 'wo-sms' ),
		'hold'       => __( 'On Hold', 'wo-sms' ),
	);
}

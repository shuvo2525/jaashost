<?php
/**
 * WO SMS — uninstall cleanup.
 *
 * Runs only when the plugin is deleted from the WordPress admin. Removes every
 * option and transient the plugin created so nothing is left behind in the DB.
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

$wosms_options = array(
	'wosms_settings',
	'wosms_username',
	'wosms_api_key',
	'wosms_sender_id',
	'wosms_signature',
	'wosms_date_format',
	'wosms_templates',
	'wosms_offer_templates',
	'wosms_history',
	'wosms_admin_sms_enabled',
	'wosms_admin_sms_phone',
	'wosms_admin_sms_msg',
);

foreach ( $wosms_options as $wosms_option ) {
	delete_option( $wosms_option );
}

/* Transients created by the server-IP helper. */
delete_transient( 'wosms_server_ip_v4' );
delete_transient( 'wosms_server_ip_v6' );

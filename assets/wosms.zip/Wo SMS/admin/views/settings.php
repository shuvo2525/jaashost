<?php
defined( 'ABSPATH' ) || exit;

$settings    = get_option( 'wosms_settings', array() );
$sms_enabled = ! empty( $settings['enabled'] ) || ! isset( $settings['enabled'] );
$username    = get_option( 'wosms_username', '' );
$api_key     = get_option( 'wosms_api_key', '' );
$sender_id   = get_option( 'wosms_sender_id', '' );
$signature   = get_option( 'wosms_signature', '' );
$date_format = get_option( 'wosms_date_format', '%d.%m.%y' );
?>
<div class="wosms-wrap">

	<div class="wosms-page-header">
		<div class="wosms-page-header__left">
			<div class="wosms-page-header__icon" style="background:#7c3aed;">
				<span class="dashicons dashicons-admin-generic"></span>
			</div>
			<div>
				<h1><?php esc_html_e( 'SMS Settings', 'wo-sms' ); ?></h1>
				<p><?php esc_html_e( 'SMS গেটওয়ে কনফিগার করুন এবং অটো নোটিফিকেশন চালু/বন্ধ করুন।', 'wo-sms' ); ?></p>
			</div>
		</div>
	</div>

	<div class="wosms-panel" style="max-width:720px; padding:28px;">
		<form id="wosms-settings-form">

			<!-- Enable -->
			<div class="wosms-field">
				<div>
					<label class="wosms-field__label"><?php esc_html_e( 'Enable SMS Notifications', 'wo-sms' ); ?></label>
					<p class="wosms-field__hint"><?php esc_html_e( 'অর্ডার স্ট্যাটাস পরিবর্তনে কাস্টমারকে স্বয়ংক্রিয় SMS পাঠান।', 'wo-sms' ); ?></p>
				</div>
				<label class="wosms-toggle">
					<input type="checkbox" id="wosms-enabled" name="sms_enabled" value="1" <?php checked( $sms_enabled ); ?>>
					<span class="wosms-toggle__track"></span>
				</label>
			</div>

			<hr class="wosms-hr">

			<!-- User Name -->
			<div style="margin-bottom:18px;">
				<label class="wosms-label"><?php esc_html_e( 'User Name', 'wo-sms' ); ?></label>
				<input type="text" name="username" id="wosms-username" class="wosms-input" value="<?php echo esc_attr( $username ); ?>" autocomplete="off">
			</div>

			<!-- API Key -->
			<div style="margin-bottom:18px;">
				<label class="wosms-label"><?php esc_html_e( 'API Key', 'wo-sms' ); ?></label>
				<input type="text" name="api_key" id="wosms-api-key" class="wosms-input" value="<?php echo esc_attr( $api_key ); ?>" autocomplete="off">
			</div>

			<!-- SenderID -->
			<div style="margin-bottom:18px;">
				<label class="wosms-label"><?php esc_html_e( 'SenderID', 'wo-sms' ); ?></label>
				<input type="text" name="sender_id" id="wosms-sender-id" class="wosms-input" value="<?php echo esc_attr( $sender_id ); ?>">
			</div>

			<!-- Signature -->
			<div style="margin-bottom:18px;">
				<label class="wosms-label"><?php esc_html_e( 'Signature', 'wo-sms' ); ?></label>
				<textarea name="signature" id="wosms-signature" rows="3" class="wosms-textarea"><?php echo esc_textarea( $signature ); ?></textarea>
				<p class="wosms-field__hint"><?php esc_html_e( 'প্রতিটি SMS এর শেষে এই সিগনেচার যোগ হবে (খালি রাখলে কিছু যোগ হবে না)।', 'wo-sms' ); ?></p>
			</div>

			<!-- Date Format -->
			<div style="margin-bottom:18px;">
				<label class="wosms-label"><?php esc_html_e( 'Date Format', 'wo-sms' ); ?></label>
				<div style="display:flex; align-items:center; gap:10px;">
					<input type="text" name="date_format" id="wosms-date-format" class="wosms-input" style="max-width:280px;" value="<?php echo esc_attr( $date_format ); ?>" placeholder="%d.%m.%y">
					<span style="font-size:12px; color:#94a3b8;"><?php esc_html_e( 'e.g: %d.%m.%y (27.01.2014)', 'wo-sms' ); ?></span>
				</div>
			</div>

			<!-- Balance -->
			<div class="wosms-balance-box">
				<div>
					<div style="font-size:12px; color:#64748b; font-weight:600; text-transform:uppercase;"><?php esc_html_e( 'Current Balance', 'wo-sms' ); ?></div>
					<div id="wosms-balance" style="font-size:20px; font-weight:700; color:#0f172a; margin-top:2px;"><span class="wosms-spinner"></span></div>
				</div>
				<button type="button" id="wosms-test-connection" class="wosms-btn wosms-btn--ghost">
					<span class="dashicons dashicons-cloud"></span> <?php esc_html_e( 'Test Connection', 'wo-sms' ); ?>
				</button>
			</div>

			<!-- Test Connection result (inline, no popup) -->
			<div id="wosms-test-result" class="wosms-inline-notice" style="display:none; margin-top:14px;"></div>

			<div style="display:flex; align-items:center; gap:14px; margin-top:22px;">
				<button type="submit" class="wosms-btn wosms-btn--primary" id="wosms-save-settings">
					<span class="dashicons dashicons-saved"></span> <?php esc_html_e( 'Save', 'wo-sms' ); ?>
				</button>
				<span id="wosms-settings-notice" class="wosms-saved-msg"><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e( 'Saved!', 'wo-sms' ); ?></span>
			</div>

		</form>
	</div>
</div>

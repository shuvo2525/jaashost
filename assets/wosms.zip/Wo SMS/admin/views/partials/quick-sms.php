<?php defined( 'ABSPATH' ) || exit; ?>
<div class="wosms-card">
	<div class="wosms-card__head" style="flex-direction:column; align-items:flex-start; gap:2px;">
		<h2><span class="dashicons dashicons-edit-page" style="color:#0ea5e9;"></span> <?php esc_html_e( 'Quick SMS / Manual', 'wo-sms' ); ?></h2>
		<p style="margin:2px 0 0; font-size:12px; color:#64748b;"><?php esc_html_e( 'ক্লায়েন্ট খুঁজে ম্যানুয়াল SMS পাঠান।', 'wo-sms' ); ?></p>
	</div>

	<div style="padding:18px 20px; display:flex; flex-direction:column; gap:16px;">

		<!-- Search Client -->
		<div>
			<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
				<label class="wosms-label" style="margin:0;"><?php esc_html_e( 'Search Client:', 'wo-sms' ); ?></label>
				<span id="wosms-qsms-count" style="font-size:12px; color:#64748b;"><?php esc_html_e( 'Selected: 0', 'wo-sms' ); ?></span>
			</div>
			<div style="position:relative;">
				<input type="text" id="wosms-qsms-search" autocomplete="off" class="wosms-input"
					   placeholder="<?php esc_attr_e( 'সব দেখতে ক্লিক করুন বা টাইপ করে খুঁজুন…', 'wo-sms' ); ?>"
					   onblur="setTimeout(function(){var d=document.getElementById('wosms-qsms-dropdown'); if(d) d.style.display='none';},200)">
				<div id="wosms-qsms-dropdown" class="wosms-dropdown"></div>
			</div>
			<div id="wosms-qsms-tags" style="display:flex; flex-wrap:wrap; gap:6px; margin-top:8px;"></div>
		</div>

		<!-- Recipient Mobiles -->
		<div>
			<label class="wosms-label"><?php esc_html_e( 'Recipient Mobiles:', 'wo-sms' ); ?></label>
			<input type="text" id="wosms-qsms-mobiles" class="wosms-input" placeholder="<?php esc_attr_e( 'কমা দিয়ে নম্বর লিখুন…', 'wo-sms' ); ?>">
		</div>

		<!-- Message -->
		<div>
			<label class="wosms-label"><?php esc_html_e( 'Message:', 'wo-sms' ); ?></label>
			<textarea id="wosms-qsms-message" rows="5" class="wosms-textarea" placeholder="<?php esc_attr_e( 'মেসেজ লিখুন…', 'wo-sms' ); ?>"></textarea>
			<div style="display:flex; justify-content:space-between; align-items:center; margin-top:4px;">
				<span style="font-size:11px; color:#94a3b8;">
					<span style="color:#0ea5e9;">&#10003;</span>
					<?php echo esc_html( sprintf( __( 'Auto-append: - %s', 'wo-sms' ), get_bloginfo( 'name' ) ) ); ?>
				</span>
				<span style="font-size:11px; color:#94a3b8;"><span id="wosms-qsms-char">0</span> <?php esc_html_e( 'chars', 'wo-sms' ); ?></span>
			</div>
		</div>

		<!-- Send Button -->
		<button type="button" id="wosms-qsms-send" class="wosms-btn wosms-btn--primary" style="width:100%; justify-content:center; padding:12px;">
			<span class="dashicons dashicons-email-alt"></span> <?php esc_html_e( 'Send Manual SMS', 'wo-sms' ); ?>
		</button>

		<div id="wosms-qsms-result" style="display:none; border-radius:8px; padding:10px 14px; font-size:13px;"></div>
	</div>
</div>

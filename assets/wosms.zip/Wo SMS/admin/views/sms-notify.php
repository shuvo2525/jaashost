<?php
defined( 'ABSPATH' ) || exit;

$sms_tab = isset( $_GET['sms_tab'] ) ? sanitize_key( $_GET['sms_tab'] ) : 'templates';

$settings = get_option( 'wosms_settings', array() );
$tpl      = get_option( 'wosms_templates', array() );
$defaults = wosms_default_templates();
$statuses = wosms_status_labels();
$enabled  = isset( $settings['enabled_statuses'] ) ? (array) $settings['enabled_statuses'] : array_keys( $defaults );

$offer_templates   = get_option( 'wosms_offer_templates', array() );
$sms_history       = get_option( 'wosms_history', array() );
$admin_sms_enabled = get_option( 'wosms_admin_sms_enabled', '' );
$admin_sms_phone   = get_option( 'wosms_admin_sms_phone', '' );
$admin_sms_msg     = get_option( 'wosms_admin_sms_msg', 'নতুন অর্ডার! #{order_id} - {customer_name} - ফোন: {customer_phone} - মোট: {order_total} টাকা। {site_name}' );

$tab_base = admin_url( 'admin.php?page=wosms-notify' );
?>
<div class="wosms-wrap">

	<!-- ── Header ── -->
	<div class="wosms-page-header" style="justify-content:space-between; align-items:center;">
		<div class="wosms-page-header__left">
			<div class="wosms-page-header__icon" style="background:#0ea5e9;">
				<span class="dashicons dashicons-email-alt"></span>
			</div>
			<div>
				<h1><?php esc_html_e( 'SMS Notify', 'wo-sms' ); ?></h1>
				<p><?php esc_html_e( 'প্রতিটি অর্ডার স্ট্যাটাসের জন্য কাস্টমারকে পাঠানো SMS টেমপ্লেট কাস্টমাইজ করুন।', 'wo-sms' ); ?></p>
			</div>
		</div>
		<!-- Balance Widget -->
		<div style="display:flex; gap:10px; align-items:center; flex-shrink:0;">
			<div style="background:#f0f9ff; border:1px solid #bae6fd; border-radius:10px; padding:10px 16px; display:flex; align-items:center; gap:10px;">
				<div style="text-align:center; min-width:80px;">
					<div style="font-size:11px; font-weight:600; color:#0369a1; text-transform:uppercase; margin-bottom:3px;"><?php esc_html_e( 'SMS Balance', 'wo-sms' ); ?></div>
					<div id="wosms-balance" style="font-size:15px; font-weight:700; color:#0f172a; line-height:1;">
						<span class="wosms-spinner"></span>
					</div>
				</div>
				<button type="button" id="wosms-balance-refresh" title="<?php esc_attr_e( 'Refresh balance', 'wo-sms' ); ?>" style="background:none;border:none;cursor:pointer;padding:2px;color:#0ea5e9;">
					<span class="dashicons dashicons-image-rotate" style="font-size:18px;width:18px;height:18px;"></span>
				</button>
			</div>
		</div>
	</div>

	<!-- ── Tab Navigation ── -->
	<div class="wosms-tabs">
		<?php
		$tabs = array(
			'templates' => array( 'icon' => 'dashicons-email-alt',  'label' => __( 'SMS Templates', 'wo-sms' ) ),
			'offers'    => array( 'icon' => 'dashicons-tag',        'label' => __( 'Offer Templates', 'wo-sms' ) ),
			'history'   => array( 'icon' => 'dashicons-list-view',  'label' => __( 'SMS History', 'wo-sms' ) ),
		);
		foreach ( $tabs as $slug => $info ) :
			$active = $sms_tab === $slug;
		?>
		<a href="<?php echo esc_url( $tab_base . '&sms_tab=' . $slug ); ?>"
		   class="wosms-tab <?php echo $active ? 'wosms-tab--active' : ''; ?>">
			<span class="dashicons <?php echo esc_attr( $info['icon'] ); ?>"></span>
			<?php echo esc_html( $info['label'] ); ?>
			<?php if ( $slug === 'history' && ! empty( $sms_history ) ) : ?>
			<span class="wosms-tab__badge"><?php echo count( $sms_history ); ?></span>
			<?php endif; ?>
		</a>
		<?php endforeach; ?>
	</div>

	<div class="wosms-panel" style="padding:28px;">

	<?php if ( 'templates' === $sms_tab ) : ?>

		<!-- Placeholders hint -->
		<div class="wosms-hint">
			<span style="font-size:13px; color:#0369a1; font-weight:600;"><?php esc_html_e( 'Available placeholders:', 'wo-sms' ); ?></span>
			<?php foreach ( array( '{customer_name}', '{order_id}', '{order_status}', '{site_name}' ) as $ph ) : ?>
			<code class="wosms-ph"><?php echo esc_html( $ph ); ?></code>
			<?php endforeach; ?>
		</div>

		<div class="wosms-cols">

			<!-- LEFT: SMS Templates -->
			<div style="flex:1; min-width:0;">
				<div class="wosms-card">
					<div class="wosms-card__head">
						<h2><span class="dashicons dashicons-email-alt" style="color:#0ea5e9;"></span> <?php esc_html_e( 'SMS Templates', 'wo-sms' ); ?></h2>
					</div>
					<div style="padding:8px 24px;">
						<?php foreach ( $statuses as $key => $label ) :
							$is_enabled = in_array( $key, $enabled, true );
							$text       = ! empty( $tpl[ $key ] ) ? $tpl[ $key ] : $defaults[ $key ];
						?>
						<div class="wosms-tpl-row">
							<label class="wosms-tpl-check">
								<input type="checkbox" id="wosms-en-<?php echo esc_attr( $key ); ?>" class="wosms-status-check" value="1" <?php checked( $is_enabled ); ?>>
								<span><?php echo esc_html( $label ); ?></span>
							</label>
							<textarea id="wosms-tpl-<?php echo esc_attr( $key ); ?>" rows="3" class="wosms-textarea"><?php echo esc_textarea( $text ); ?></textarea>
						</div>
						<?php endforeach; ?>
					</div>
					<div class="wosms-card__foot">
						<button type="button" id="wosms-save-templates" class="wosms-btn wosms-btn--primary">
							<span class="dashicons dashicons-saved"></span> <?php esc_html_e( 'Save Changes', 'wo-sms' ); ?>
						</button>
						<span id="wosms-tpl-status" class="wosms-saved-msg"><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e( 'Saved successfully!', 'wo-sms' ); ?></span>
					</div>
				</div>
			</div>

			<!-- RIGHT: Quick SMS + Admin Notification -->
			<div class="wosms-side">
				<?php include WOSMS_PLUGIN_DIR . 'admin/views/partials/quick-sms.php'; ?>

				<!-- Admin Notification Card -->
				<div class="wosms-card">
					<div class="wosms-card__head" style="justify-content:space-between;">
						<h2><span class="dashicons dashicons-admin-users" style="color:#7c3aed;"></span> <?php esc_html_e( 'Admin Notification', 'wo-sms' ); ?></h2>
						<label class="wosms-toggle">
							<input type="checkbox" id="wosms-admin-enabled" value="1" <?php checked( $admin_sms_enabled, '1' ); ?>>
							<span class="wosms-toggle__track"></span>
						</label>
					</div>
					<div style="padding:16px 18px; display:flex; flex-direction:column; gap:12px;">
						<p style="margin:0; font-size:12px; color:#64748b;"><?php esc_html_e( 'নতুন অর্ডার হলে এই নম্বরে SMS যাবে।', 'wo-sms' ); ?></p>
						<div>
							<label class="wosms-label"><?php esc_html_e( 'Admin Phone Number', 'wo-sms' ); ?></label>
							<input type="text" id="wosms-admin-phone" value="<?php echo esc_attr( $admin_sms_phone ); ?>" placeholder="880XXXXXXXXXX" class="wosms-input">
						</div>
						<div>
							<label class="wosms-label"><?php esc_html_e( 'Message Template', 'wo-sms' ); ?></label>
							<textarea id="wosms-admin-msg" rows="4" class="wosms-textarea"><?php echo esc_textarea( $admin_sms_msg ); ?></textarea>
							<p style="margin:4px 0 0; font-size:11px; color:#94a3b8;">{order_id} {customer_name} {customer_phone} {order_total} {site_name}</p>
						</div>
						<button type="button" id="wosms-save-admin" class="wosms-btn wosms-btn--purple" style="width:100%; justify-content:center;">
							<span class="dashicons dashicons-saved"></span> <?php esc_html_e( 'Save', 'wo-sms' ); ?>
						</button>
						<span id="wosms-admin-status" class="wosms-saved-msg" style="text-align:center;"><span class="dashicons dashicons-yes-alt"></span> <?php esc_html_e( 'Saved!', 'wo-sms' ); ?></span>
					</div>
				</div>
			</div>

		</div>

	<?php elseif ( 'offers' === $sms_tab ) : ?>

		<div class="wosms-cols">

			<!-- LEFT: Offer Templates List -->
			<div style="flex:1; min-width:0;">
				<div class="wosms-card">
					<div class="wosms-card__head" style="justify-content:space-between;">
						<h2><span class="dashicons dashicons-tag" style="color:#0ea5e9;"></span> <?php esc_html_e( 'Saved Offer Templates', 'wo-sms' ); ?></h2>
						<span style="font-size:12px; color:#64748b;"><?php echo count( $offer_templates ); ?> <?php esc_html_e( 'templates', 'wo-sms' ); ?></span>
					</div>
					<div id="wosms-offer-list" style="padding:8px 0;">
						<?php if ( empty( $offer_templates ) ) : ?>
						<div id="wosms-offer-empty" style="padding:32px; text-align:center; color:#94a3b8;">
							<span class="dashicons dashicons-tag" style="font-size:32px;width:32px;height:32px;margin-bottom:8px;display:block;"></span>
							<?php esc_html_e( 'এখনো কোনো অফার টেমপ্লেট নেই। ডানপাশের ফর্ম থেকে যোগ করুন।', 'wo-sms' ); ?>
						</div>
						<?php else : ?>
						<?php foreach ( $offer_templates as $otpl ) : ?>
						<div class="wosms-offer-item" data-id="<?php echo esc_attr( $otpl['id'] ); ?>">
							<div style="flex:1; min-width:0;">
								<div style="font-size:13px; font-weight:700; color:#0f172a; margin-bottom:4px;"><?php echo esc_html( $otpl['name'] ); ?></div>
								<div class="wosms-offer-msg"><?php echo esc_html( $otpl['message'] ); ?></div>
							</div>
							<div style="display:flex; gap:6px; flex-shrink:0;">
								<button type="button" class="wosms-offer-edit" data-id="<?php echo esc_attr( $otpl['id'] ); ?>" data-name="<?php echo esc_attr( $otpl['name'] ); ?>" data-msg="<?php echo esc_attr( $otpl['message'] ); ?>">
									<span class="dashicons dashicons-edit"></span>
								</button>
								<button type="button" class="wosms-offer-delete" data-id="<?php echo esc_attr( $otpl['id'] ); ?>">
									<span class="dashicons dashicons-trash"></span>
								</button>
							</div>
						</div>
						<?php endforeach; ?>
						<?php endif; ?>
					</div>
				</div>
			</div>

			<!-- RIGHT: Add / Edit Form -->
			<div style="width:320px; flex-shrink:0;">
				<div class="wosms-card" style="position:sticky; top:32px;">
					<div class="wosms-card__head">
						<h2 id="wosms-offer-form-title"><span class="dashicons dashicons-plus-alt" style="color:#0ea5e9;"></span> <?php esc_html_e( 'Add New Template', 'wo-sms' ); ?></h2>
					</div>
					<div style="padding:18px 20px; display:flex; flex-direction:column; gap:14px;">
						<input type="hidden" id="wosms-offer-edit-id" value="">
						<div>
							<label class="wosms-label"><?php esc_html_e( 'Template Name:', 'wo-sms' ); ?></label>
							<input type="text" id="wosms-offer-name" class="wosms-input" placeholder="<?php esc_attr_e( 'e.g. Eid Offer, Flash Sale…', 'wo-sms' ); ?>">
						</div>
						<div>
							<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
								<label class="wosms-label" style="margin:0;"><?php esc_html_e( 'Message:', 'wo-sms' ); ?></label>
								<span style="font-size:11px; color:#94a3b8;"><span id="wosms-offer-char">0</span> chars</span>
							</div>
							<textarea id="wosms-offer-message" rows="6" class="wosms-textarea" placeholder="<?php esc_attr_e( 'Write offer message…', 'wo-sms' ); ?>"></textarea>
							<p style="margin:4px 0 0; font-size:11px; color:#94a3b8;"><?php esc_html_e( 'Placeholders: {customer_name} {site_name}', 'wo-sms' ); ?></p>
						</div>
						<div style="display:flex; gap:8px;">
							<button type="button" id="wosms-offer-save" class="wosms-btn wosms-btn--primary" style="flex:1; justify-content:center;">
								<span class="dashicons dashicons-saved"></span> <?php esc_html_e( 'Save Template', 'wo-sms' ); ?>
							</button>
							<button type="button" id="wosms-offer-cancel" class="wosms-btn wosms-btn--ghost" style="display:none;"><?php esc_html_e( 'Cancel', 'wo-sms' ); ?></button>
						</div>
						<div id="wosms-offer-result" style="display:none; border-radius:8px; padding:8px 12px; font-size:13px;"></div>
					</div>
				</div>
			</div>

		</div>

	<?php elseif ( 'history' === $sms_tab ) : ?>

		<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
			<div>
				<h2 style="margin:0; font-size:16px; color:#0f172a; display:flex; align-items:center; gap:8px;">
					<span class="dashicons dashicons-list-view" style="color:#0ea5e9;"></span> <?php esc_html_e( 'SMS History', 'wo-sms' ); ?>
				</h2>
				<p style="margin:4px 0 0; font-size:13px; color:#64748b;">
					<?php echo sprintf( esc_html__( 'Total %d SMS logged (last 200)', 'wo-sms' ), count( $sms_history ) ); ?>
				</p>
			</div>
			<button type="button" id="wosms-clear-history" class="wosms-btn wosms-btn--danger">
				<span class="dashicons dashicons-trash"></span> <?php esc_html_e( 'Clear History', 'wo-sms' ); ?>
			</button>
		</div>

		<div class="wosms-card">
			<?php if ( empty( $sms_history ) ) : ?>
			<div style="padding:48px; text-align:center; color:#94a3b8;">
				<span class="dashicons dashicons-list-view" style="font-size:40px;width:40px;height:40px;margin-bottom:12px;display:block;"></span>
				<?php esc_html_e( 'No SMS history yet.', 'wo-sms' ); ?>
			</div>
			<?php else : ?>
			<div style="overflow-x:auto;">
				<table class="wosms-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Date / Time', 'wo-sms' ); ?></th>
							<th><?php esc_html_e( 'Recipient', 'wo-sms' ); ?></th>
							<th><?php esc_html_e( 'Message', 'wo-sms' ); ?></th>
							<th><?php esc_html_e( 'Type', 'wo-sms' ); ?></th>
							<th><?php esc_html_e( 'Status', 'wo-sms' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $sms_history as $row ) :
							$is_sent     = isset( $row['status'] ) && $row['status'] === 'sent';
							$is_auto     = isset( $row['type'] ) && $row['type'] === 'auto';
							$msg_preview = mb_substr( $row['message'] ?? '', 0, 80 ) . ( mb_strlen( $row['message'] ?? '' ) > 80 ? '…' : '' );
						?>
						<tr>
							<td style="white-space:nowrap; font-size:12px;">
								<?php
								$raw_date = $row['date'] ?? '';
								if ( $raw_date && $raw_date !== '—' ) {
									$ts = strtotime( $raw_date );
									echo esc_html( wosms_format_date( $ts ) );
									echo '<br><span style="color:#94a3b8;">' . esc_html( date( 'g:i A', $ts ) ) . '</span>';
								} else {
									echo '—';
								}
								?>
							</td>
							<td style="font-weight:600; white-space:nowrap;">
								<?php echo esc_html( $row['mobile'] ?? '—' ); ?>
								<?php if ( ! empty( $row['order_id'] ) ) : ?>
								<br><a href="<?php echo esc_url( admin_url( 'post.php?post=' . $row['order_id'] . '&action=edit' ) ); ?>" style="font-size:11px; color:#0ea5e9; font-weight:400;">#<?php echo esc_html( $row['order_id'] ); ?></a>
								<?php endif; ?>
							</td>
							<td style="color:#64748b; max-width:340px;"><?php echo esc_html( $msg_preview ); ?></td>
							<td style="white-space:nowrap;">
								<span class="wosms-pill <?php echo $is_auto ? 'wosms-pill--auto' : 'wosms-pill--manual'; ?>">
									<?php echo $is_auto ? esc_html__( 'Auto', 'wo-sms' ) : esc_html__( 'Manual', 'wo-sms' ); ?>
								</span>
							</td>
							<td style="white-space:nowrap;">
								<span class="wosms-pill <?php echo $is_sent ? 'wosms-pill--sent' : 'wosms-pill--failed'; ?>">
									<?php echo $is_sent ? esc_html__( 'Sent', 'wo-sms' ) : esc_html__( 'Failed', 'wo-sms' ); ?>
								</span>
							</td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
			<?php endif; ?>
		</div>

	<?php endif; ?>

	</div>
</div>

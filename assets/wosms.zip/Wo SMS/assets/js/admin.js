/* global jQuery, wosms_params */
( function ( $ ) {
	'use strict';

	var P = window.wosms_params || {};

	function post( action, data ) {
		return $.post( P.ajax_url, $.extend( { action: action, nonce: P.nonce }, data || {} ) );
	}

	/* ── Connection state on the Test Connection button ──────────────── */
	function setConnState( ok ) {
		var $btn = $( '#wosms-test-connection' );
		if ( ! $btn.length ) { return; }
		if ( ok ) {
			$btn.html( '<span class="dashicons dashicons-yes-alt"></span> ' + ( P.i18n.connected || 'Connected' ) )
				.removeClass( 'wosms-btn--ghost' ).addClass( 'wosms-btn--success' );
		} else {
			$btn.html( '<span class="dashicons dashicons-cloud"></span> ' + ( P.i18n.test_connection || 'Test Connection' ) )
				.removeClass( 'wosms-btn--success' ).addClass( 'wosms-btn--ghost' );
		}
	}

	/* ── Balance ─────────────────────────────────────────────────────── */
	function loadBalance() {
		var $bal = $( '#wosms-balance' );
		if ( ! $bal.length ) { return; }
		$bal.html( '<span class="wosms-spinner"></span>' );
		post( 'wosms_get_balance' ).done( function ( res ) {
			if ( res && res.success && res.data && res.data.balance ) {
				$bal.text( res.data.balance );
				setConnState( true );
				return;
			}
			/* Show why it failed — a bare dash hides gateway errors like
			 * "IP Black List." or a wrong API endpoint. */
			var msg = res && res.data && res.data.message;
			if ( msg ) {
				$bal.html( '<span class="wosms-balance-error"></span>' ).find( '.wosms-balance-error' ).text( msg );
			} else {
				$bal.text( '—' );
			}
			setConnState( false );
		} ).fail( function () { $bal.text( '—' ); setConnState( false ); } );
	}

	$( document ).on( 'click', '#wosms-balance-refresh', function ( e ) {
		e.preventDefault();
		loadBalance();
	} );

	/* ── Settings form ───────────────────────────────────────────────── */
	$( document ).on( 'submit', '#wosms-settings-form', function ( e ) {
		e.preventDefault();
		var $btn    = $( '#wosms-save-settings' );
		var $notice = $( '#wosms-settings-notice' );
		var orig    = $btn.html();
		$btn.prop( 'disabled', true ).html( P.i18n.saving );
		post( 'wosms_save_settings', {
			sms_enabled: $( '#wosms-enabled' ).is( ':checked' ) ? 1 : '',
			username:    $( '#wosms-username' ).val(),
			api_key:     $( '#wosms-api-key' ).val(),
			sender_id:   $( '#wosms-sender-id' ).val(),
			signature:   $( '#wosms-signature' ).val(),
			date_format: $( '#wosms-date-format' ).val()
		} ).done( function ( res ) {
			$btn.prop( 'disabled', false ).html( orig );
			if ( res && res.success ) {
				$notice.css( 'display', 'inline-flex' );
				setTimeout( function () { $notice.hide(); }, 2500 );
				loadBalance();
			} else {
				alert( ( res && res.data && res.data.message ) || 'Error' );
			}
		} ).fail( function () {
			$btn.prop( 'disabled', false ).html( orig );
			alert( 'Request failed.' );
		} );
	} );

	$( document ).on( 'click', '#wosms-test-connection', function ( e ) {
		e.preventDefault();
		var $btn = $( this );
		var $out = $( '#wosms-test-result' );
		$btn.prop( 'disabled', true ).html( '<span class="wosms-spinner"></span> ' + P.i18n.testing );
		post( 'wosms_test_connection' ).done( function ( res ) {
			$btn.prop( 'disabled', false );
			if ( res && res.success ) {
				if ( res.data && res.data.balance ) { $( '#wosms-balance' ).text( res.data.balance ); }
				setConnState( true );
				showNotice( $out, true, ( res.data && res.data.message ) || 'Connected!' );
			} else {
				setConnState( false );
				showNotice( $out, false, ( res && res.data && res.data.message ) || 'Connection failed.' );
			}
		} ).fail( function () {
			$btn.prop( 'disabled', false );
			setConnState( false );
			showNotice( $out, false, 'Request failed.' );
		} );
	} );

	function showNotice( $el, ok, msg ) {
		$el.text( msg )
			.toggleClass( 'wosms-inline-notice--ok', !! ok )
			.toggleClass( 'wosms-inline-notice--err', ! ok )
			.css( 'display', 'block' );
	}

	/* ── SMS templates ───────────────────────────────────────────────── */
	var STATUSES = [ 'pending', 'paid', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled', 'return', 'hold' ];

	$( document ).on( 'click', '#wosms-save-templates', function ( e ) {
		e.preventDefault();
		var $btn = $( this );
		var orig = $btn.html();
		var data = {};
		STATUSES.forEach( function ( s ) {
			data[ 'tpl_' + s ] = $( '#wosms-tpl-' + s ).val();
			if ( $( '#wosms-en-' + s ).is( ':checked' ) ) { data[ 'en_' + s ] = 1; }
		} );
		$btn.prop( 'disabled', true ).html( P.i18n.saving );
		post( 'wosms_save_templates', data ).done( function ( res ) {
			$btn.prop( 'disabled', false ).html( orig );
			if ( res && res.success ) {
				var $s = $( '#wosms-tpl-status' ).css( 'display', 'inline-flex' );
				setTimeout( function () { $s.hide(); }, 2500 );
			} else {
				alert( ( res && res.data && res.data.message ) || 'Error' );
			}
		} ).fail( function () {
			$btn.prop( 'disabled', false ).html( orig );
			alert( 'Request failed.' );
		} );
	} );

	/* ── Admin notification ──────────────────────────────────────────── */
	$( document ).on( 'click', '#wosms-save-admin', function ( e ) {
		e.preventDefault();
		var $btn = $( this );
		var orig = $btn.html();
		$btn.prop( 'disabled', true ).html( P.i18n.saving );
		post( 'wosms_save_admin_sms', {
			enabled: $( '#wosms-admin-enabled' ).is( ':checked' ) ? 1 : '',
			phone:   $( '#wosms-admin-phone' ).val(),
			msg:     $( '#wosms-admin-msg' ).val()
		} ).done( function ( res ) {
			$btn.prop( 'disabled', false ).html( orig );
			if ( res && res.success ) {
				var $s = $( '#wosms-admin-status' ).css( 'display', 'inline-flex' );
				setTimeout( function () { $s.hide(); }, 2500 );
			}
		} ).fail( function () {
			$btn.prop( 'disabled', false ).html( orig );
		} );
	} );

	/* ── Quick / Manual SMS ──────────────────────────────────────────── */
	var selected = {}; // phone -> name

	function renderTags() {
		var $tags = $( '#wosms-qsms-tags' ).empty();
		var phones = Object.keys( selected );
		phones.forEach( function ( ph ) {
			$( '<span class="wosms-tag"></span>' )
				.text( selected[ ph ] + ' (' + ph + ') ' )
				.append( $( '<button type="button">&times;</button>' ).data( 'phone', ph ) )
				.appendTo( $tags );
		} );
		$( '#wosms-qsms-count' ).text( 'Selected: ' + phones.length );
		$( '#wosms-qsms-mobiles' ).val( phones.join( ', ' ) );
	}

	$( document ).on( 'click', '#wosms-qsms-tags .wosms-tag button', function () {
		delete selected[ $( this ).data( 'phone' ) ];
		renderTags();
	} );

	var searchTimer = null;
	function doSearch() {
		var term = $( '#wosms-qsms-search' ).val();
		var $dd  = $( '#wosms-qsms-dropdown' );
		$dd.html( '<div class="wosms-dropdown__item">' + P.i18n.searching + '</div>' ).show();
		post( 'wosms_search_customers', { term: term } ).done( function ( res ) {
			$dd.empty();
			if ( res && res.success && res.data && res.data.length ) {
				res.data.forEach( function ( c ) {
					if ( ! c.phone ) { return; }
					$( '<div class="wosms-dropdown__item"></div>' )
						.html( '<strong>' + escapeHtml( c.name ) + '</strong><small>' + escapeHtml( c.phone ) + ( c.email ? ' · ' + escapeHtml( c.email ) : '' ) + '</small>' )
						.on( 'mousedown', function () {
							selected[ c.phone ] = c.name;
							renderTags();
							$dd.hide();
							$( '#wosms-qsms-search' ).val( '' );
						} )
						.appendTo( $dd );
				} );
			} else {
				$dd.html( '<div class="wosms-dropdown__item">No results.</div>' );
			}
		} );
	}

	$( document ).on( 'focus', '#wosms-qsms-search', doSearch );
	$( document ).on( 'input', '#wosms-qsms-search', function () {
		clearTimeout( searchTimer );
		searchTimer = setTimeout( doSearch, 300 );
	} );

	$( document ).on( 'input', '#wosms-qsms-message', function () {
		$( '#wosms-qsms-char' ).text( this.value.length );
	} );

	$( document ).on( 'click', '#wosms-qsms-send', function ( e ) {
		e.preventDefault();
		var $btn     = $( this );
		var orig     = $btn.html();
		var mobiles  = $( '#wosms-qsms-mobiles' ).val();
		var message  = $( '#wosms-qsms-message' ).val();
		var $result  = $( '#wosms-qsms-result' );
		if ( ! mobiles || ! message ) {
			showResult( $result, false, 'নম্বর ও মেসেজ দুটোই দিন।' );
			return;
		}
		$btn.prop( 'disabled', true ).html( '<span class="wosms-spinner"></span> ' + P.i18n.sending );
		post( 'wosms_send_manual_sms', { mobiles: mobiles, message: message } ).done( function ( res ) {
			$btn.prop( 'disabled', false ).html( orig );
			if ( res && res.success ) {
				showResult( $result, true, ( res.data && res.data.message ) || 'Sent!' );
				$( '#wosms-qsms-message' ).val( '' );
				$( '#wosms-qsms-char' ).text( '0' );
				selected = {};
				renderTags();
				loadBalance();
			} else {
				showResult( $result, false, ( res && res.data && res.data.message ) || 'Failed.' );
			}
		} ).fail( function () {
			$btn.prop( 'disabled', false ).html( orig );
			showResult( $result, false, 'Request failed.' );
		} );
	} );

	function showResult( $el, ok, msg ) {
		$el.text( msg ).css( {
			display: 'block',
			background: ok ? '#dcfce7' : '#fee2e2',
			color: ok ? '#166534' : '#991b1b'
		} );
	}

	/* ── Offer templates ─────────────────────────────────────────────── */
	$( document ).on( 'input', '#wosms-offer-message', function () {
		$( '#wosms-offer-char' ).text( this.value.length );
	} );

	$( document ).on( 'click', '#wosms-offer-save', function ( e ) {
		e.preventDefault();
		var $btn    = $( this );
		var orig    = $btn.html();
		var id      = $( '#wosms-offer-edit-id' ).val();
		var name    = $( '#wosms-offer-name' ).val();
		var message = $( '#wosms-offer-message' ).val();
		var $result = $( '#wosms-offer-result' );
		if ( ! name || ! message ) {
			showResult( $result, false, 'Name ও Message দিন।' );
			return;
		}
		$btn.prop( 'disabled', true ).html( P.i18n.saving );
		post( 'wosms_save_offer_template', { id: id, name: name, message: message } ).done( function ( res ) {
			$btn.prop( 'disabled', false ).html( orig );
			if ( res && res.success ) {
				location.reload();
			} else {
				showResult( $result, false, ( res && res.data && res.data.message ) || 'Error' );
			}
		} ).fail( function () {
			$btn.prop( 'disabled', false ).html( orig );
			showResult( $result, false, 'Request failed.' );
		} );
	} );

	$( document ).on( 'click', '.wosms-offer-edit', function () {
		$( '#wosms-offer-edit-id' ).val( $( this ).data( 'id' ) );
		$( '#wosms-offer-name' ).val( $( this ).data( 'name' ) );
		$( '#wosms-offer-message' ).val( $( this ).data( 'msg' ) ).trigger( 'input' );
		$( '#wosms-offer-form-title' ).html( '<span class="dashicons dashicons-edit" style="color:#0ea5e9;"></span> Edit Template' );
		$( '#wosms-offer-cancel' ).show();
		$( 'html, body' ).animate( { scrollTop: $( '#wosms-offer-name' ).offset().top - 120 }, 200 );
	} );

	$( document ).on( 'click', '#wosms-offer-cancel', function () {
		$( '#wosms-offer-edit-id, #wosms-offer-name, #wosms-offer-message' ).val( '' );
		$( '#wosms-offer-char' ).text( '0' );
		$( '#wosms-offer-form-title' ).html( '<span class="dashicons dashicons-plus-alt" style="color:#0ea5e9;"></span> Add New Template' );
		$( this ).hide();
	} );

	$( document ).on( 'click', '.wosms-offer-delete', function () {
		if ( ! confirm( 'এই টেমপ্লেটটি ডিলিট করবেন?' ) ) { return; }
		var id = $( this ).data( 'id' );
		post( 'wosms_delete_offer_template', { id: id } ).done( function ( res ) {
			if ( res && res.success ) { location.reload(); }
		} );
	} );

	/* ── History ─────────────────────────────────────────────────────── */
	$( document ).on( 'click', '#wosms-clear-history', function ( e ) {
		e.preventDefault();
		if ( ! confirm( 'সব SMS হিস্ট্রি মুছে ফেলবেন?' ) ) { return; }
		post( 'wosms_clear_history' ).done( function ( res ) {
			if ( res && res.success ) { location.reload(); }
		} );
	} );

	/* ── Utils ───────────────────────────────────────────────────────── */
	function escapeHtml( s ) {
		return String( s ).replace( /[&<>"']/g, function ( c ) {
			return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ c ];
		} );
	}

	/* ── Init ────────────────────────────────────────────────────────── */
	$( function () {
		loadBalance();
		$( '#wosms-qsms-message' ).trigger( 'input' );
		$( '#wosms-offer-message' ).trigger( 'input' );
	} );

} )( jQuery );
